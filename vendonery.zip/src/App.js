export default function App() {
  return (
    <div style={{ fontFamily: 'Arial, sans-serif', padding: '20px' }}>
      <header style={{ textAlign: 'center', marginBottom: '40px' }}>
        <h1 style={{ color: '#2563eb' }}>The Vendonery</h1>
        <nav>
          <a href="#about" style={{ margin: '0 10px' }}>About</a>
          <a href="#ads" style={{ margin: '0 10px' }}>Advertise</a>
          <a href="#partner" style={{ margin: '0 10px' }}>Partner</a>
          <a href="#contact" style={{ margin: '0 10px' }}>Contact</a>
        </nav>
      </header>

      <section id="about" style={{ marginBottom: '40px' }}>
        <h2>About The Vendonery</h2>
        <p>
          The Vendonery is your on-campus stationery vending machine, providing
          students with essentials 24/7 – quick, simple, and reliable.
        </p>
      </section>

      <section id="ads" style={{ marginBottom: '40px' }}>
        <h2>Advertise With Us</h2>
        <p>
          Our vending machines feature digital screens that play advertisements
          for students throughout the day. Reach a highly engaged audience by
          placing your ads with us.
        </p>
      </section>

      <section id="partner" style={{ marginBottom: '40px' }}>
        <h2>Bring The Vendonery To Your College</h2>
        <p>
          Colleges can partner with us to set up The Vendonery on their campus.
          Provide your students with an innovative, reliable solution for
          stationery needs while also generating value through ad partnerships.
        </p>
      </section>

      <section id="contact" style={{ marginBottom: '40px' }}>
        <h2>Contact Us</h2>
        <p>Email: contact@vendonery.com</p>
      </section>

      <footer style={{ textAlign: 'center', marginTop: '40px', color: '#555' }}>
        <p>© {new Date().getFullYear()} The Vendonery. All rights reserved.</p>
      </footer>
    </div>
  );
}
